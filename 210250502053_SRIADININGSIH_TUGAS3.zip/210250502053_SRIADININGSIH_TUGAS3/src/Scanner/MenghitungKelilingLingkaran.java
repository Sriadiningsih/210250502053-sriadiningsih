/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Scanner;
import java.util.Scanner;

/**
 *
 * @SRIADININGSIH
 */
public class MenghitungKelilingLingkaran {
    public static void main(String[] args) {
       Scanner scan = new Scanner(System.in);
       double keliling, jari_jari;
       
       System.out.print("input nilai jari_jari =");
       jari_jari = Double.valueOf(scan.nextLine());
       
       keliling = 2* 3.14 * jari_jari;
       System.out.println("hasil keliling lingkaran = "+ keliling);
       
      
    }
    
}
