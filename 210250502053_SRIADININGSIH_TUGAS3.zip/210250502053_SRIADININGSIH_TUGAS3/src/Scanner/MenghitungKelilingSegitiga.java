/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Scanner;
import java.util.Scanner;

/**
 *
 * @SRIADININGSIH
 */
public class MenghitungKelilingSegitiga {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int keliling, sisi;
        
        System.out.print("input nilai sisi =");
        sisi = scan.nextInt();
        
        keliling = sisi + sisi + sisi;
        System.out.println("hasil keliling segitiga ="+ keliling);
                
    }
    
}
