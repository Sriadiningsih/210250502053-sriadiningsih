/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Scanner;
import java.util.Scanner;

/**
 *
 * @SRIADININGSIIH
 */
public class MenghitungKelilingJajarGenjang {
    public static void main(String[] args) {
       Scanner scan = new Scanner(System.in);
       int keliling, panjang, lebar;
       
       System.out.print("input nilai panjang =");
       panjang = scan.nextInt();
       
       System.out.print("input nilai lebar =");
       lebar = scan.nextInt();
       
       keliling = 2 * panjang + 2 * lebar;
       System.out.println("hasil keliling jajargenjang = "+keliling);
    }
    
}
