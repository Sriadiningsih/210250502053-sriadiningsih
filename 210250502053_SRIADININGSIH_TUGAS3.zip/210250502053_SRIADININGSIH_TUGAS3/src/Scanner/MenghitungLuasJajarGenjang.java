/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Scanner;
import java.util.Scanner;

/**
 *
 * @SRIADININGSIH
 */
public class MenghitungLuasJajarGenjang {
    public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    int luas, alas, tinggi;
    
    System.out.print("input nilai alas =");
    alas = scan.nextInt();
    
    System.out.print("input nilai tinggi =");
    tinggi = scan.nextInt();
    
    luas = alas * tinggi;
    System.out.println("hasil luas jajargenjang"+luas);
    
    
    }
    
}
